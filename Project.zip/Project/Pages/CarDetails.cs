public class CarDetails {
    public int car_ID;
    public string car_Name;
    public string car_Model;
    public string car_Website;
    public string car_Image;


    public CarDetails(int id, string carname, string carmodel, string carwebsite, string carimage){
        car_ID = id;
        car_Name = carname;
        car_Model = carmodel;
        car_Website = carwebsite;
        car_Image = carimage;
    }

    
}